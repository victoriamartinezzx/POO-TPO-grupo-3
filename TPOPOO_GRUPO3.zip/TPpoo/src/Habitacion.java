public abstract class Habitacion {
    private int numero;
    private boolean estado;
    private double precio;

    public Habitacion (int numero, boolean estado, double precio, Hotel hotel) {
        this.numero = numero;
        this.estado = estado;
        this.precio = precio;
        hotel.getListaHabitaciones().agregar(this);
    }

    public int getNumero() {
        return numero;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    public void actualizarPrecio(double nuevoPrecio) {
    	setPrecio(nuevoPrecio);
    };



}
