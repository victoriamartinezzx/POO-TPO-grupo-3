public class HabitacionSuite extends Habitacion {
    private double COSTO_SPA_PRIVADO = 50.0;
    private boolean spaPrivadoIncluido;

    public HabitacionSuite(int numero, double precio, Hotel hotel) {
        super(numero, false, precio,hotel);
        this.spaPrivadoIncluido = false; 
    }


    public void incluirSpaPrivado() {
        this.spaPrivadoIncluido = true;
        this.calcularAdicionales();
    }

    public void calcularAdicionales() {
        double precioTotal = getPrecio();
        if (spaPrivadoIncluido) {
            precioTotal += COSTO_SPA_PRIVADO;
        }
        this.actualizarPrecio(precioTotal);
    }
}