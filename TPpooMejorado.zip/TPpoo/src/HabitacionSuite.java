public class HabitacionSuite extends Habitacion {
    private static final double COSTO_SPA_PRIVADO = 50.0;
    private boolean spaPrivadoIncluido;

    public HabitacionSuite(int numero, double precio) {
        super(numero, false, precio);
        this.spaPrivadoIncluido = false; // Por defecto, el spa privado no está incluido
    }

    @Override
    public void actualizarPrecio(double nuevoPrecio) {
        setPrecio(nuevoPrecio);
        System.out.println("Precio actualizado para Habitación Suite " + getNumero() + ": $" + nuevoPrecio);
    }

    @Override
    public void cambiarEstado(String nuevoEstado) {
        setEstado(nuevoEstado.equals("ocupada"));
        System.out.println("Estado de la Habitación Suite " + getNumero() + " cambiado a: " + (getEstado() ? "Ocupada" : "Disponible"));
    }

    public void incluirSpaPrivado() {
        this.spaPrivadoIncluido = true;
        System.out.println("Spa privado incluido en la Habitación Suite " + getNumero());
    }

    public double calcularPrecioTotal() {
        double precioTotal = getPrecio();
        if (spaPrivadoIncluido) {
            precioTotal += COSTO_SPA_PRIVADO;
            System.out.println("Costo adicional por spa privado: $" + COSTO_SPA_PRIVADO);
        }
        System.out.println("Precio total para Habitación Suite " + getNumero() + ": $" + precioTotal);
        return precioTotal;
    }
}