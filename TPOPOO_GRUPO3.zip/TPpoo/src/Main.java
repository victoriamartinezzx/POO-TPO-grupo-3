public class Main {
    public static void main(String[] args) {
        System.out.println("HOTEL");
        try {
        	Hotel alvear = new Hotel("Av. Cordoba 1234");
            HabitacionIndividual hab = new HabitacionIndividual(1, 40.5,alvear);
            HabitacionIndividual hab1 = new HabitacionIndividual(2, 40.5,alvear);
            HabitacionIndividual hab2 = new HabitacionIndividual(3, 40.5,alvear);

            HabitacionDoble habD = new HabitacionDoble(5,  45.6,alvear);
            HabitacionDoble habDdos = new HabitacionDoble(6,  45.6,alvear);
            HabitacionDoble habDtres = new HabitacionDoble(7, 45.6,alvear);

            HabitacionSuite habS = new HabitacionSuite(8,  50,alvear);
            HabitacionSuite habSdos = new HabitacionSuite(9, 50,alvear);
            HabitacionSuite habStres = new HabitacionSuite(10,50,alvear);

            habDtres.incluirFrigobar();
            habS.incluirSpaPrivado();

            alvear.getListaHabitaciones().mostrar();


            Cliente cliente1 = new Cliente ("Victoria Martinez", 1163013, 23);
            System.out.println("Cliente creado: " + cliente1.getNombre());

            Cliente cliente2 = new Cliente ("Angelina Navello", 1172220, 50);
            System.out.println("Cliente creado: " + cliente2.getNombre());

            Cliente cliente3 = new Cliente ("Sofia Besada", 1167090, 30);
            System.out.println("Cliente creado: " + cliente3.getNombre());

            Cliente cliente4 = new Cliente ("Tomas torres", 1167976, 18);
            System.out.println("Cliente creado: " + cliente4.getNombre());

            Cliente cliente5 = new Cliente ("Lucas Faure", 1138280, 80);
            System.out.println("Cliente creado: " + cliente5.getNombre());

            Reserva nuevaReservaUno = new Reserva(cliente4, habDtres, "10/9", "11/11",alvear);
            Reserva nuevaReservaDos = new Reserva(cliente1, hab, "10/2", "14/3",alvear);
            Reserva nuevaReservaTres = new Reserva(cliente3, hab1, "17/8", "27/8",alvear);
            Reserva nuevaReservaCuatro = new Reserva(cliente5, habS, "1/8", "15/9",alvear);
            Reserva nuevaReservaCinco = new Reserva(cliente2, habStres, "23/12", "29/12",alvear);

            alvear.getListaReservas().mostrar();

            System.out.println("Estado de las habitaciones después de las reservas: ");
            alvear.getListaHabitaciones().mostrar();


        } catch (NombreInvalidoException e) {
            System.err.println (e.getMessage());
        }catch (EdadInvalidaException e) {
            System.err.println(e.getMessage());
        }catch (HabitacionOcupadaError e) {
            System.err.println(e.getMessage());
        }

        
    }

}