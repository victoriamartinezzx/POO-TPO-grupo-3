public class HabitacionDoble extends Habitacion {
    private static final double COSTO_FRIGOBAR = 30.0;
    private boolean frigobarIncluido;

    public HabitacionDoble(int numero, double precio) {
        super(numero, false, precio);
        this.frigobarIncluido = false; // Por defecto, el frigobar no está incluido
    }

    @Override
    public void actualizarPrecio(double nuevoPrecio) {
        setPrecio(nuevoPrecio);
        System.out.println("Precio actualizado para Habitación Doble " + getNumero() + ": $" + nuevoPrecio);
    }

    @Override
    public void cambiarEstado(String nuevoEstado) {
        setEstado(nuevoEstado.equals("ocupada"));
        System.out.println("Estado de la Habitación Doble " + getNumero() + " cambiado a: " + (getEstado() ? "Ocupada" : "Disponible"));
    }

    public void incluirFrigobar() {
        this.frigobarIncluido = true;
        System.out.println("Frigobar incluido en la Habitación Doble " + getNumero());
    }

    public double calcularPrecioTotal() {
        double precioTotal = getPrecio();
        if (frigobarIncluido) {
            precioTotal += COSTO_FRIGOBAR;
            System.out.println("Costo adicional por frigobar: $" + COSTO_FRIGOBAR);
        }
        System.out.println("Precio total para Habitación Doble " + getNumero() + ": $" + precioTotal);
        return precioTotal;
    }
}