public class HabitacionOcupadaError extends Exception {
	public HabitacionOcupadaError(String message) {
        super(message);
    }
}
