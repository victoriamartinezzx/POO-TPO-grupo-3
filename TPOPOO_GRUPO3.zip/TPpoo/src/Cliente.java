public class Cliente {
    private String nombre;
    private int documento;
    private int edad;

    public Cliente (String nombre, int documento, int edad) throws NombreInvalidoException, EdadInvalidaException{
        if (nombre == null || nombre.trim().isEmpty() || !nombre.matches("[a-zA-Z ]+")) {
            throw new NombreInvalidoException("El nombre no puede estar vacio y debe contener solo letras.");
        }
        if (edad < 18 ) {
            throw new EdadInvalidaException ("La edad debe ser mayor a 18");
        }
        this.nombre = nombre;
        this.documento = documento;
        this.edad = edad;

    }
    public String getNombre() {
        return nombre;
    }

    public int getDocumento() {
        return documento;
    }

}
