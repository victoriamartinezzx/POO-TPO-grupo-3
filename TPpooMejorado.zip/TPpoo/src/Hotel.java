import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private String nombre;
    private String direccion;
    private List<Habitacion> listaHabitaciones;
    private List<Reserva> listaReservas;
    private List<Cliente> listaClientes;
    private Temporada temporadaActual;

    public Hotel (String nombre, String direccion, Temporada temporada) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.listaReservas = new ArrayList<>();
        this.listaReservas = new ArrayList<>();
        this.listaClientes = new ArrayList<>();
        this.temporadaActual = temporada;
        ajustarPreciosPorTemporada();
    }

    public void agregarHabitacion (Habitacion habitacion) {
        listaHabitaciones.add(habitacion);
        System.out.println("Habitación agregada: " + habitacion.getNumero());
    }

    public void eliminarHabitacion (int numeroHabitacion) {
        listaHabitaciones.removeIf(habitacion -> habitacion.getNumero() == numeroHabitacion);
        System.out.println("Habitación eliminada: " + numeroHabitacion);
    }

    public void mostrarHabitaciones() {
        for (Habitacion habitacion : listaHabitaciones) {
            System.out.println("Habitación " + habitacion.getNumero() + " - Estado: " + habitacion.getEstado());
        }
    }

    public void realizarReserva (Reserva reserva) {
        listaReservas.add(reserva);
        System.out.println("Reserva realizada para el cliente: " + reserva.getCliente());
    }

    public void cancelarReserva (int idReserva) {
        listaReservas.removeIf(reserva -> reserva.getId() == idReserva);
        System.out.println("Reserva cancelada con ID: " + idReserva);
    }

    public void mostrarReservas() {
        for (Reserva reserva : listaReservas) {
            reserva.mostrarDetalles();
        }
    }

    public void agregarCliente (Cliente cliente) {
        listaClientes.add(cliente);
        System.out.println("Cliente agregado con éxito! " + cliente.getNombre());
    }
    public void mostrarClientes() {
        for (Cliente cliente : listaClientes) {
            System.out.println ("Cliente: " + cliente.getNombre() + " - Documento: " + cliente.getDocumento());
        }
    }

    public void ajustarPreciosPorTemporada() {
        for (Habitacion habitacion : listaHabitaciones) {
            double precioBase = habitacion.getPrecio();
            switch (temporadaActual) {
                case ALTA:
                    habitacion.setPrecio(precioBase * 1.5); // 50% más caro en temporada alta
                    break;
                case MEDIA:
                    habitacion.setPrecio(precioBase * 1.2); // 20% más caro en temporada media
                    break;
                case BAJA:
                    habitacion.setPrecio(precioBase); // Precio base en temporada baja
                    break;
            }
        }
    }


}
