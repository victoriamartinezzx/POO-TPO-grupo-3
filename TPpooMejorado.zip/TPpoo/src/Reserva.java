public class Reserva {
    private static int contador = 0;
    private int id;
    private String cliente;
    private Habitacion habitacion;
    private String fechaInicio;
    private String fechaFin;
    private String estado;
    private boolean checkInRealizado = false;
    private boolean checkOutRealizado = false;

    public Reserva(String cliente, Habitacion habitacion, String fechaInicio, String fechaFin, String estado) {
        this.id = ++contador;
        this.cliente = cliente;
        this.habitacion = habitacion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = "pendiente";
    }

    public int getId() {
        return id;
    }

    public String getCliente() {
        return cliente;
    }

    public void confirmarReserva() {
        this.estado = "confirmada";
        System.out.println("Reserva confirmada con ID: " + id);
    }

    public void cancelarReserva() {
        this.estado = "cancelada";
        System.out.println("Reserva cancelada con ID: " + id);
    }

    public void mostrarDetalles() {
        System.out.println("Reserva ID: " + id + " - Cliente: " + cliente + " - Habitacion: " + habitacion.getNumero() +
                " - Fecha Inicio: " + fechaInicio + " - Fecha Fin: " + fechaFin + " - Estado: " + estado);
    }

    public void realizarCheckIn() {
        if (!checkInRealizado) {
            this.checkInRealizado = true;
            this.estado = "ocupada";
            habitacion.setEstado(true); // Marcar la habitación como ocupada
            System.out.println("Check-in realizado para la reserva ID: " + id);
        } else {
            System.out.println("El check-in ya ha sido realizado para la reserva ID: " + id);
        }
    }

    public void realizarCheckOut() {
        if (checkInRealizado && !checkOutRealizado) {
            this.checkOutRealizado = true;
            this.estado = "finalizada";
            habitacion.setEstado(false); // Marcar la habitación como disponible
            System.out.println("Check-out realizado para la reserva ID: " + id);
        } else if (!checkInRealizado) {
            System.out.println("No se puede realizar check-out sin haber hecho check-in para la reserva ID: " + id);
        } else {
            System.out.println("El check-out ya ha sido realizado para la reserva ID: " + id);
        }
    }


}
