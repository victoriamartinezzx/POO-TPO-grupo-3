public class HabitacionIndividual extends Habitacion {

    public HabitacionIndividual(int numero, double precio) {
        super(numero, false, precio);
    }

    @Override
    public void actualizarPrecio(double nuevoPrecio) {
        setPrecio(nuevoPrecio);
        System.out.println("Precio actualizado para Habitación Individual " + getNumero() + ": $" + nuevoPrecio);
    }

    @Override
    public void cambiarEstado(String nuevoEstado) {
        setEstado(nuevoEstado.equals("ocupada"));
        System.out.println("Estado de la Habitación Individual " + getNumero() + " cambiado a: " + (getEstado() ? "Ocupada" : "Disponible"));
    }
}
