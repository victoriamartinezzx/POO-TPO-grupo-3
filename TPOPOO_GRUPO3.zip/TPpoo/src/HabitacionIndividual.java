public class HabitacionIndividual extends Habitacion {

    public HabitacionIndividual(int numero, double precio, Hotel hotel) {
        super(numero, false, precio, hotel);
    }


}
