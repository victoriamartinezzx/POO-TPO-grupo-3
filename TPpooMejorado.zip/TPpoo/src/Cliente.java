import java.util.List;

public class Cliente {
    private String nombre;
    private int documento;
    private int telefono;

    public Cliente (String nombre, int documento, int telefono) {
        this.nombre = nombre;
        this.documento = documento;
        this.telefono = telefono;

    }

    public String getNombre() {
        return nombre;
    }

    public int getDocumento() {
        return documento;
    }

    public void mostrarReservas (List<Reserva> reservas) {
        System.out.println("Reservas del cliente: " + nombre);
        for (Reserva reserva : reservas) {
            if (reserva.getCliente().equals(nombre)) {
                reserva.mostrarDetalles();
            }
        }

    }
}
