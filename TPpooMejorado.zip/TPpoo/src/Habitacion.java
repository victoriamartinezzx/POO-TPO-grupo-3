public abstract class Habitacion {
    private int numero;
    private boolean estado;
    private double precio;

    public Habitacion (int numero, boolean estado, double precio) {
        this.numero = numero;
        this.estado = estado;
        this.precio = precio;

    }

    public int getNumero() {
        return numero;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public abstract void actualizarPrecio (double nuevoPrecio);
    public abstract void cambiarEstado (String nuevoEstado);



}
