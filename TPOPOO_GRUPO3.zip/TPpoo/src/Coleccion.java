import java.util.ArrayList;
public interface Coleccion <x>{
    void agregar(x elemento);
    void eliminar(x elemento);
    ArrayList<x> obtenerTodos();
    void mostrar();

}
