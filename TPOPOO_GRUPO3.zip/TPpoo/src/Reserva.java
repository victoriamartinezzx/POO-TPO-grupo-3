public class Reserva {
    private static int contador = 0;
    private int id;
    private Cliente cliente;
    private Habitacion habitacion;
    private String fechaInicio;
    private String fechaFin;
    private boolean estado;

    public Reserva(Cliente cliente, Habitacion habitacion, String fechaInicio, String fechaFin, Hotel hotel) throws HabitacionOcupadaError{
        this.id = ++contador;
        this.cliente = cliente;
        this.habitacion = habitacion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = true;
        if(habitacion.getEstado()) {
        	throw new HabitacionOcupadaError ("La habitación está ocupada");
        }
        habitacion.setEstado(true);
        this.ajustarPreciosPorTemporada();
        hotel.getListaReservas().agregar(this);
    }

    public int getId() {
        return id;
    }

    public String getCliente() {
        return cliente.getNombre();
    }
    public String getFechaInicio() {
        return this.fechaInicio;
    }
    public Habitacion getHabitacion() {
        return habitacion;
    }

    public void mostrarDetalles() {
        System.out.println("Reserva ID: " + id + " - Cliente: " + cliente.getNombre() + " - Habitacion: " + this.getHabitacion().getNumero() +
                " - Fecha Inicio: " + fechaInicio + " - Fecha Fin: " + fechaFin + "- Precio: " + this.getHabitacion().getPrecio());
    }

    public void ajustarPreciosPorTemporada() {
        double precioBase = this.getHabitacion().getPrecio();
        String[] fechaPartes = this.getFechaInicio().split("/");
        int mesNumero = Integer.parseInt(fechaPartes[1]);
        if (mesNumero == 12 || mesNumero <= 3) {
            this.getHabitacion().setPrecio(precioBase * 1.5);
        } else if (mesNumero == 7 || mesNumero == 8) {
            this.getHabitacion().setPrecio(precioBase * 1.2); 
        } else {
            this.getHabitacion().setPrecio(precioBase); 
        }
    }
}
