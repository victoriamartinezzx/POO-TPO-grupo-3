public class Hotel {
	private String direccion;
	private Coleccion<Habitacion> listaHab;
	private Coleccion<Reserva> listaRes;
	
	public Hotel(String direccion) {
		this.direccion = direccion;
		Coleccion<Habitacion> listaH = new ListaHabitaciones();
		Coleccion<Reserva> listaR = new ListaReservas();
		listaHab = listaH;
		listaRes = listaR;
		
	}
	public Coleccion<Habitacion> getListaHabitaciones() {
		return listaHab;
	}
	
	public Coleccion<Reserva> getListaReservas() {
		return listaRes;
	}
}
