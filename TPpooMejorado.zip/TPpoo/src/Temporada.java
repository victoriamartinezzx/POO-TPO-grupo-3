public enum Temporada {
    ALTA, MEDIA, BAJA;
}
