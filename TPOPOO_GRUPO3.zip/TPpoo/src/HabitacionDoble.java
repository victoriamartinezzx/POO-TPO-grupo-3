public class HabitacionDoble extends Habitacion {
    private double COSTO_FRIGOBAR = 30.0;
    private boolean frigobarIncluido;

    public HabitacionDoble(int numero, double precio,Hotel hotel) {
        super(numero, false, precio,hotel);
        this.frigobarIncluido = false; 
    }


    public void incluirFrigobar() {
        this.frigobarIncluido = true;
        this.calcularAdicionales();
    }

    public void calcularAdicionales() {
        double precioTotal = getPrecio();
        if (frigobarIncluido) {
            precioTotal += COSTO_FRIGOBAR; 
        this.actualizarPrecio(precioTotal);
    }

    }
}