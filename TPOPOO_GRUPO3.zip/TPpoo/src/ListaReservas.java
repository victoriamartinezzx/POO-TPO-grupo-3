import java.util.ArrayList;
public class ListaReservas implements Coleccion <Reserva>{
    private ArrayList<Reserva> reservas = new ArrayList<>();

    @Override
    public void agregar(Reserva reserva) {
        reservas.add(reserva);
    }

    @Override
    public void eliminar(Reserva reserva) {
        reservas.remove(reserva);
    }

    @Override
    public ArrayList<Reserva> obtenerTodos() {
        return new ArrayList<>(reservas);
    }

    public void mostrar() {
        for (int i = 0; i< reservas.size(); i++) {
            System.out.print ("Detalle de la reserva: " );
            reservas.get(i).mostrarDetalles();
        }
    }

    public int cantidadReservas() {
        return reservas.size();
    }

}
