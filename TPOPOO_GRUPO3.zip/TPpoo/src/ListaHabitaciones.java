import java.util.ArrayList;

public class ListaHabitaciones implements Coleccion<Habitacion> {
    private ArrayList<Habitacion> habitaciones = new ArrayList<>();

    @Override
    public void agregar(Habitacion habitacion) {
        habitaciones.add(habitacion);
    }

    @Override
    public void eliminar(Habitacion habitacion) {
        habitaciones.remove(habitacion);
    }

    @Override
    public ArrayList<Habitacion> obtenerTodos() {
        return new ArrayList<>(habitaciones);
    }

    public void mostrar() {
        for (int i = 0; i< habitaciones.size(); i++) {
            String estadoNuevo;
            if (!habitaciones.get(i).getEstado()) {
                estadoNuevo = "disponible";
            } else {
                estadoNuevo = "ocupado";
            }
            System.out.println ("Numero de habitación: " + habitaciones.get(i).getNumero() + "; Estado " + estadoNuevo);
        }

    }

}
